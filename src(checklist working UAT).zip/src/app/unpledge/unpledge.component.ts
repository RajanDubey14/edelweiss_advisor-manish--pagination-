import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unpledge',
  templateUrl: './unpledge.component.html',
  styleUrls: ['./unpledge.component.css']
})
export class UnpledgeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
