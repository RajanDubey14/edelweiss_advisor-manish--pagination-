import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-kycdocument',
  templateUrl: './kycdocument.component.html',
  styleUrls: ['./kycdocument.component.css']
})
export class KycdocumentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
